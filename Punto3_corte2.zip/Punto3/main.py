# main.py
from antlr4 import *
from fourierLexer import fourierLexer
from fourierParser import fourierParser
from MyVisitor import MyVisitor

def main():
    # Lee el archivo de entrada con la expresión a procesar
    input_stream = FileStream('entrada.txt')
    
    # Generar lexer y parser
    lexer = fourierLexer(input_stream)
    stream = CommonTokenStream(lexer)
    parser = fourierParser(stream)
    
    # Generar el árbol de análisis sintáctico (parse tree)
    tree = parser.prog()
    
    # Crear el visitor para recorrer el árbol
    visitor = MyVisitor()
    visitor.visit(tree)

if __name__ == '__main__':
    main()
