# MyVisitor.py
import math
from fourierVisitor import fourierVisitor

class MyVisitor(fourierVisitor):
    def _init_(self):
        self.result = None

    def visitRecta(self, ctx):
        print("La transformada de Fourier para esta función sigue la forma: Tsinc(T*w/(2π))")
        return 
    
    def visitTriang(self, ctx):
        print("La transformada de Fourier para esta función sigue la forma: T*sinc^2(T*w/(2π))")
        return
    
    def visitSign(self, ctx):
        print("La transformada de Fourier para esta función sigue la forma: 1/(jπf)")
        return
    
    def visitU(self, ctx):
        print("La transformada de Fourier para esta función sigue la forma: 1/(jw) + (jπf)")
        return
    
    def visitD(self, ctx):
        print("La transformada de Fourier para esta función sigue la forma: 2πδ(-w)")
        return
    
    def visitCos(self, ctx):
        print("La transformada de Fourier para esta función sigue la forma: πδ(w-w0) + πδ(w+w0)")
        return
    
    def visitSin(self, ctx):
        print("La transformada de Fourier para esta función sigue la forma: (π/j)δ(w-w0) - (π/j)δ(w+w0)")
        return
    
    def visitSum(self, ctx):
        print("La transformada de Fourier para esta función sigue la forma:  1/Ts * SUM( inf, n = -inf , 2πδ(w  -n *((2π)/Ts) ))")
        return
    
    def visitRectPulse(self, ctx):
        # Verifica que tanto VAR como VARN no sean None antes de continuar
        if ctx.VARN() is None or ctx.VAR() is None:
            print("Error: faltan argumentos para la función rect.")
            return None
        
        # Obtener el valor de T
        T = ctx.VARN().getText()
        omega = 2 * math.pi  # Frecuencia angular
        sinc_value = math.sin(omega * float(T) / 2) / (omega / 2)  # Cálculo del sinc
        
        print(f"La transformada de Fourier para el pulso rectangular es: {T} * sinc({T} * w / (2π))")
        print(f"Resultado aproximado: {sinc_value}")
        return sinc_value
