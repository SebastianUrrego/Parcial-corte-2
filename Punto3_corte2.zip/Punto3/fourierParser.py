# Generated from fourier.g4 by ANTLR 4.13.0
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,30,158,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,1,0,4,0,22,8,0,11,0,12,0,23,1,1,1,1,1,
        1,1,2,1,2,1,2,1,2,1,2,3,2,34,8,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,
        1,2,1,2,1,2,3,2,47,8,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,
        2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,
        2,1,2,3,2,77,8,2,3,2,79,8,2,1,2,1,2,1,2,1,2,1,2,3,2,86,8,2,3,2,88,
        8,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,3,2,102,8,2,
        1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,1,3,3,3,116,8,3,1,4,
        1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,1,4,3,4,130,8,4,1,5,1,5,
        1,5,1,5,1,5,1,5,1,5,1,5,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,7,1,7,
        1,7,1,7,1,7,1,7,1,8,1,8,1,9,1,9,1,9,0,0,10,0,2,4,6,8,10,12,14,16,
        18,0,3,2,0,2,2,11,13,2,0,25,25,28,28,1,0,21,24,164,0,21,1,0,0,0,
        2,25,1,0,0,0,4,101,1,0,0,0,6,103,1,0,0,0,8,117,1,0,0,0,10,131,1,
        0,0,0,12,139,1,0,0,0,14,147,1,0,0,0,16,153,1,0,0,0,18,155,1,0,0,
        0,20,22,3,2,1,0,21,20,1,0,0,0,22,23,1,0,0,0,23,21,1,0,0,0,23,24,
        1,0,0,0,24,1,1,0,0,0,25,26,3,4,2,0,26,27,5,29,0,0,27,3,1,0,0,0,28,
        33,5,1,0,0,29,34,5,25,0,0,30,31,5,25,0,0,31,32,5,2,0,0,32,34,5,26,
        0,0,33,29,1,0,0,0,33,30,1,0,0,0,34,35,1,0,0,0,35,36,5,3,0,0,36,37,
        5,4,0,0,37,38,5,5,0,0,38,39,3,6,3,0,39,40,5,6,0,0,40,102,1,0,0,0,
        41,46,5,1,0,0,42,47,5,25,0,0,43,44,5,25,0,0,44,45,5,2,0,0,45,47,
        5,26,0,0,46,42,1,0,0,0,46,43,1,0,0,0,47,48,1,0,0,0,48,49,5,3,0,0,
        49,50,5,4,0,0,50,51,5,5,0,0,51,52,3,8,4,0,52,53,5,6,0,0,53,102,1,
        0,0,0,54,55,5,7,0,0,55,56,5,25,0,0,56,57,5,3,0,0,57,58,5,4,0,0,58,
        59,5,5,0,0,59,60,3,10,5,0,60,61,5,6,0,0,61,102,1,0,0,0,62,63,5,8,
        0,0,63,64,5,25,0,0,64,65,5,3,0,0,65,66,5,4,0,0,66,67,5,5,0,0,67,
        68,3,12,6,0,68,69,5,6,0,0,69,102,1,0,0,0,70,71,5,9,0,0,71,72,5,25,
        0,0,72,102,5,3,0,0,73,78,5,10,0,0,74,76,5,26,0,0,75,77,7,0,0,0,76,
        75,1,0,0,0,76,77,1,0,0,0,77,79,1,0,0,0,78,74,1,0,0,0,78,79,1,0,0,
        0,79,80,1,0,0,0,80,81,5,25,0,0,81,102,5,3,0,0,82,87,5,14,0,0,83,
        85,5,26,0,0,84,86,7,0,0,0,85,84,1,0,0,0,85,86,1,0,0,0,86,88,1,0,
        0,0,87,83,1,0,0,0,87,88,1,0,0,0,88,89,1,0,0,0,89,90,5,25,0,0,90,
        102,5,3,0,0,91,92,5,15,0,0,92,93,5,25,0,0,93,94,5,2,0,0,94,95,5,
        26,0,0,95,102,5,3,0,0,96,97,5,16,0,0,97,98,5,25,0,0,98,99,5,17,0,
        0,99,100,5,26,0,0,100,102,5,18,0,0,101,28,1,0,0,0,101,41,1,0,0,0,
        101,54,1,0,0,0,101,62,1,0,0,0,101,70,1,0,0,0,101,73,1,0,0,0,101,
        82,1,0,0,0,101,91,1,0,0,0,101,96,1,0,0,0,102,5,1,0,0,0,103,104,5,
        19,0,0,104,105,3,14,7,0,105,106,5,3,0,0,106,107,5,20,0,0,107,108,
        5,19,0,0,108,109,3,14,7,0,109,115,5,3,0,0,110,111,5,20,0,0,111,112,
        5,19,0,0,112,113,3,14,7,0,113,114,5,3,0,0,114,116,1,0,0,0,115,110,
        1,0,0,0,115,116,1,0,0,0,116,7,1,0,0,0,117,118,5,19,0,0,118,119,3,
        14,7,0,119,120,5,3,0,0,120,121,5,20,0,0,121,122,5,19,0,0,122,123,
        3,14,7,0,123,129,5,3,0,0,124,125,5,20,0,0,125,126,5,19,0,0,126,127,
        3,14,7,0,127,128,5,3,0,0,128,130,1,0,0,0,129,124,1,0,0,0,129,130,
        1,0,0,0,130,9,1,0,0,0,131,132,5,19,0,0,132,133,3,14,7,0,133,134,
        5,3,0,0,134,135,5,20,0,0,135,136,5,19,0,0,136,137,3,14,7,0,137,138,
        5,3,0,0,138,11,1,0,0,0,139,140,5,19,0,0,140,141,3,14,7,0,141,142,
        5,3,0,0,142,143,5,20,0,0,143,144,5,19,0,0,144,145,3,14,7,0,145,146,
        5,3,0,0,146,13,1,0,0,0,147,148,3,16,8,0,148,149,5,20,0,0,149,150,
        5,25,0,0,150,151,3,18,9,0,151,152,3,16,8,0,152,15,1,0,0,0,153,154,
        7,1,0,0,154,17,1,0,0,0,155,156,7,2,0,0,156,19,1,0,0,0,10,23,33,46,
        76,78,85,87,101,115,129
    ]

class fourierParser ( Parser ):

    grammarFileName = "fourier.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'f('", "'/'", "')'", "'='", "'{'", "'}'", 
                     "'sign('", "'u('", "'d('", "'cos('", "'+'", "'-'", 
                     "'*'", "'sin('", "'rect('", "'SUM( inf, n = -inf , d('", 
                     "'-n'", "'))'", "'('", "','", "'<'", "'<='", "'>'", 
                     "'>='" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "VAR", "VARN", "INT", "NUMBER", "NEWLINE", 
                      "WS" ]

    RULE_prog = 0
    RULE_start = 1
    RULE_function = 2
    RULE_parameters = 3
    RULE_parameters1 = 4
    RULE_parameters2 = 5
    RULE_parameters3 = 6
    RULE_expr = 7
    RULE_value = 8
    RULE_comp_operator = 9

    ruleNames =  [ "prog", "start", "function", "parameters", "parameters1", 
                   "parameters2", "parameters3", "expr", "value", "comp_operator" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    T__14=15
    T__15=16
    T__16=17
    T__17=18
    T__18=19
    T__19=20
    T__20=21
    T__21=22
    T__22=23
    T__23=24
    VAR=25
    VARN=26
    INT=27
    NUMBER=28
    NEWLINE=29
    WS=30

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.0")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def start(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(fourierParser.StartContext)
            else:
                return self.getTypedRuleContext(fourierParser.StartContext,i)


        def getRuleIndex(self):
            return fourierParser.RULE_prog

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProg" ):
                listener.enterProg(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProg" ):
                listener.exitProg(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProg" ):
                return visitor.visitProg(self)
            else:
                return visitor.visitChildren(self)




    def prog(self):

        localctx = fourierParser.ProgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_prog)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 21 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 20
                self.start()
                self.state = 23 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 116610) != 0)):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StartContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def function(self):
            return self.getTypedRuleContext(fourierParser.FunctionContext,0)


        def NEWLINE(self):
            return self.getToken(fourierParser.NEWLINE, 0)

        def getRuleIndex(self):
            return fourierParser.RULE_start

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStart" ):
                listener.enterStart(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStart" ):
                listener.exitStart(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStart" ):
                return visitor.visitStart(self)
            else:
                return visitor.visitChildren(self)




    def start(self):

        localctx = fourierParser.StartContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_start)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 25
            self.function()
            self.state = 26
            self.match(fourierParser.NEWLINE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FunctionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return fourierParser.RULE_function

     
        def copyFrom(self, ctx:ParserRuleContext):
            super().copyFrom(ctx)



    class TriangContext(FunctionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a fourierParser.FunctionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def parameters1(self):
            return self.getTypedRuleContext(fourierParser.Parameters1Context,0)

        def VAR(self):
            return self.getToken(fourierParser.VAR, 0)
        def VARN(self):
            return self.getToken(fourierParser.VARN, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTriang" ):
                listener.enterTriang(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTriang" ):
                listener.exitTriang(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTriang" ):
                return visitor.visitTriang(self)
            else:
                return visitor.visitChildren(self)


    class DContext(FunctionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a fourierParser.FunctionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def VAR(self):
            return self.getToken(fourierParser.VAR, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterD" ):
                listener.enterD(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitD" ):
                listener.exitD(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitD" ):
                return visitor.visitD(self)
            else:
                return visitor.visitChildren(self)


    class UContext(FunctionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a fourierParser.FunctionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def VAR(self):
            return self.getToken(fourierParser.VAR, 0)
        def parameters3(self):
            return self.getTypedRuleContext(fourierParser.Parameters3Context,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterU" ):
                listener.enterU(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitU" ):
                listener.exitU(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitU" ):
                return visitor.visitU(self)
            else:
                return visitor.visitChildren(self)


    class CosContext(FunctionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a fourierParser.FunctionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def VAR(self):
            return self.getToken(fourierParser.VAR, 0)
        def VARN(self):
            return self.getToken(fourierParser.VARN, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCos" ):
                listener.enterCos(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCos" ):
                listener.exitCos(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCos" ):
                return visitor.visitCos(self)
            else:
                return visitor.visitChildren(self)


    class SinContext(FunctionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a fourierParser.FunctionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def VAR(self):
            return self.getToken(fourierParser.VAR, 0)
        def VARN(self):
            return self.getToken(fourierParser.VARN, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSin" ):
                listener.enterSin(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSin" ):
                listener.exitSin(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSin" ):
                return visitor.visitSin(self)
            else:
                return visitor.visitChildren(self)


    class SignContext(FunctionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a fourierParser.FunctionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def VAR(self):
            return self.getToken(fourierParser.VAR, 0)
        def parameters2(self):
            return self.getTypedRuleContext(fourierParser.Parameters2Context,0)


        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSign" ):
                listener.enterSign(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSign" ):
                listener.exitSign(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSign" ):
                return visitor.visitSign(self)
            else:
                return visitor.visitChildren(self)


    class SumContext(FunctionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a fourierParser.FunctionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def VAR(self):
            return self.getToken(fourierParser.VAR, 0)
        def VARN(self):
            return self.getToken(fourierParser.VARN, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSum" ):
                listener.enterSum(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSum" ):
                listener.exitSum(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSum" ):
                return visitor.visitSum(self)
            else:
                return visitor.visitChildren(self)


    class RectPulseContext(FunctionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a fourierParser.FunctionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def VAR(self):
            return self.getToken(fourierParser.VAR, 0)
        def VARN(self):
            return self.getToken(fourierParser.VARN, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRectPulse" ):
                listener.enterRectPulse(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRectPulse" ):
                listener.exitRectPulse(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRectPulse" ):
                return visitor.visitRectPulse(self)
            else:
                return visitor.visitChildren(self)


    class RectaContext(FunctionContext):

        def __init__(self, parser, ctx:ParserRuleContext): # actually a fourierParser.FunctionContext
            super().__init__(parser)
            self.copyFrom(ctx)

        def parameters(self):
            return self.getTypedRuleContext(fourierParser.ParametersContext,0)

        def VAR(self):
            return self.getToken(fourierParser.VAR, 0)
        def VARN(self):
            return self.getToken(fourierParser.VARN, 0)

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRecta" ):
                listener.enterRecta(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRecta" ):
                listener.exitRecta(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRecta" ):
                return visitor.visitRecta(self)
            else:
                return visitor.visitChildren(self)



    def function(self):

        localctx = fourierParser.FunctionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_function)
        self._la = 0 # Token type
        try:
            self.state = 101
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,7,self._ctx)
            if la_ == 1:
                localctx = fourierParser.RectaContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 28
                self.match(fourierParser.T__0)
                self.state = 33
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
                if la_ == 1:
                    self.state = 29
                    self.match(fourierParser.VAR)
                    pass

                elif la_ == 2:
                    self.state = 30
                    self.match(fourierParser.VAR)
                    self.state = 31
                    self.match(fourierParser.T__1)
                    self.state = 32
                    self.match(fourierParser.VARN)
                    pass


                self.state = 35
                self.match(fourierParser.T__2)
                self.state = 36
                self.match(fourierParser.T__3)
                self.state = 37
                self.match(fourierParser.T__4)
                self.state = 38
                self.parameters()
                self.state = 39
                self.match(fourierParser.T__5)
                pass

            elif la_ == 2:
                localctx = fourierParser.TriangContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 41
                self.match(fourierParser.T__0)
                self.state = 46
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,2,self._ctx)
                if la_ == 1:
                    self.state = 42
                    self.match(fourierParser.VAR)
                    pass

                elif la_ == 2:
                    self.state = 43
                    self.match(fourierParser.VAR)
                    self.state = 44
                    self.match(fourierParser.T__1)
                    self.state = 45
                    self.match(fourierParser.VARN)
                    pass


                self.state = 48
                self.match(fourierParser.T__2)
                self.state = 49
                self.match(fourierParser.T__3)
                self.state = 50
                self.match(fourierParser.T__4)
                self.state = 51
                self.parameters1()
                self.state = 52
                self.match(fourierParser.T__5)
                pass

            elif la_ == 3:
                localctx = fourierParser.SignContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 54
                self.match(fourierParser.T__6)
                self.state = 55
                self.match(fourierParser.VAR)
                self.state = 56
                self.match(fourierParser.T__2)
                self.state = 57
                self.match(fourierParser.T__3)
                self.state = 58
                self.match(fourierParser.T__4)
                self.state = 59
                self.parameters2()
                self.state = 60
                self.match(fourierParser.T__5)
                pass

            elif la_ == 4:
                localctx = fourierParser.UContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 62
                self.match(fourierParser.T__7)
                self.state = 63
                self.match(fourierParser.VAR)
                self.state = 64
                self.match(fourierParser.T__2)
                self.state = 65
                self.match(fourierParser.T__3)
                self.state = 66
                self.match(fourierParser.T__4)
                self.state = 67
                self.parameters3()
                self.state = 68
                self.match(fourierParser.T__5)
                pass

            elif la_ == 5:
                localctx = fourierParser.DContext(self, localctx)
                self.enterOuterAlt(localctx, 5)
                self.state = 70
                self.match(fourierParser.T__8)
                self.state = 71
                self.match(fourierParser.VAR)
                self.state = 72
                self.match(fourierParser.T__2)
                pass

            elif la_ == 6:
                localctx = fourierParser.CosContext(self, localctx)
                self.enterOuterAlt(localctx, 6)
                self.state = 73
                self.match(fourierParser.T__9)
                self.state = 78
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==26:
                    self.state = 74
                    self.match(fourierParser.VARN)
                    self.state = 76
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if (((_la) & ~0x3f) == 0 and ((1 << _la) & 14340) != 0):
                        self.state = 75
                        _la = self._input.LA(1)
                        if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 14340) != 0)):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()




                self.state = 80
                self.match(fourierParser.VAR)
                self.state = 81
                self.match(fourierParser.T__2)
                pass

            elif la_ == 7:
                localctx = fourierParser.SinContext(self, localctx)
                self.enterOuterAlt(localctx, 7)
                self.state = 82
                self.match(fourierParser.T__13)
                self.state = 87
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==26:
                    self.state = 83
                    self.match(fourierParser.VARN)
                    self.state = 85
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    if (((_la) & ~0x3f) == 0 and ((1 << _la) & 14340) != 0):
                        self.state = 84
                        _la = self._input.LA(1)
                        if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 14340) != 0)):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()




                self.state = 89
                self.match(fourierParser.VAR)
                self.state = 90
                self.match(fourierParser.T__2)
                pass

            elif la_ == 8:
                localctx = fourierParser.RectPulseContext(self, localctx)
                self.enterOuterAlt(localctx, 8)
                self.state = 91
                self.match(fourierParser.T__14)
                self.state = 92
                self.match(fourierParser.VAR)
                self.state = 93
                self.match(fourierParser.T__1)
                self.state = 94
                self.match(fourierParser.VARN)
                self.state = 95
                self.match(fourierParser.T__2)
                pass

            elif la_ == 9:
                localctx = fourierParser.SumContext(self, localctx)
                self.enterOuterAlt(localctx, 9)
                self.state = 96
                self.match(fourierParser.T__15)
                self.state = 97
                self.match(fourierParser.VAR)
                self.state = 98
                self.match(fourierParser.T__16)
                self.state = 99
                self.match(fourierParser.VARN)
                self.state = 100
                self.match(fourierParser.T__17)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParametersContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(fourierParser.ExprContext)
            else:
                return self.getTypedRuleContext(fourierParser.ExprContext,i)


        def getRuleIndex(self):
            return fourierParser.RULE_parameters

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParameters" ):
                listener.enterParameters(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParameters" ):
                listener.exitParameters(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParameters" ):
                return visitor.visitParameters(self)
            else:
                return visitor.visitChildren(self)




    def parameters(self):

        localctx = fourierParser.ParametersContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_parameters)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 103
            self.match(fourierParser.T__18)
            self.state = 104
            self.expr()
            self.state = 105
            self.match(fourierParser.T__2)
            self.state = 106
            self.match(fourierParser.T__19)
            self.state = 107
            self.match(fourierParser.T__18)
            self.state = 108
            self.expr()
            self.state = 109
            self.match(fourierParser.T__2)
            self.state = 115
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==20:
                self.state = 110
                self.match(fourierParser.T__19)
                self.state = 111
                self.match(fourierParser.T__18)
                self.state = 112
                self.expr()
                self.state = 113
                self.match(fourierParser.T__2)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Parameters1Context(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(fourierParser.ExprContext)
            else:
                return self.getTypedRuleContext(fourierParser.ExprContext,i)


        def getRuleIndex(self):
            return fourierParser.RULE_parameters1

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParameters1" ):
                listener.enterParameters1(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParameters1" ):
                listener.exitParameters1(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParameters1" ):
                return visitor.visitParameters1(self)
            else:
                return visitor.visitChildren(self)




    def parameters1(self):

        localctx = fourierParser.Parameters1Context(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_parameters1)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 117
            self.match(fourierParser.T__18)
            self.state = 118
            self.expr()
            self.state = 119
            self.match(fourierParser.T__2)
            self.state = 120
            self.match(fourierParser.T__19)
            self.state = 121
            self.match(fourierParser.T__18)
            self.state = 122
            self.expr()
            self.state = 123
            self.match(fourierParser.T__2)
            self.state = 129
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==20:
                self.state = 124
                self.match(fourierParser.T__19)
                self.state = 125
                self.match(fourierParser.T__18)
                self.state = 126
                self.expr()
                self.state = 127
                self.match(fourierParser.T__2)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Parameters2Context(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(fourierParser.ExprContext)
            else:
                return self.getTypedRuleContext(fourierParser.ExprContext,i)


        def getRuleIndex(self):
            return fourierParser.RULE_parameters2

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParameters2" ):
                listener.enterParameters2(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParameters2" ):
                listener.exitParameters2(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParameters2" ):
                return visitor.visitParameters2(self)
            else:
                return visitor.visitChildren(self)




    def parameters2(self):

        localctx = fourierParser.Parameters2Context(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_parameters2)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 131
            self.match(fourierParser.T__18)
            self.state = 132
            self.expr()
            self.state = 133
            self.match(fourierParser.T__2)
            self.state = 134
            self.match(fourierParser.T__19)
            self.state = 135
            self.match(fourierParser.T__18)
            self.state = 136
            self.expr()
            self.state = 137
            self.match(fourierParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Parameters3Context(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(fourierParser.ExprContext)
            else:
                return self.getTypedRuleContext(fourierParser.ExprContext,i)


        def getRuleIndex(self):
            return fourierParser.RULE_parameters3

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParameters3" ):
                listener.enterParameters3(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParameters3" ):
                listener.exitParameters3(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParameters3" ):
                return visitor.visitParameters3(self)
            else:
                return visitor.visitChildren(self)




    def parameters3(self):

        localctx = fourierParser.Parameters3Context(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_parameters3)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 139
            self.match(fourierParser.T__18)
            self.state = 140
            self.expr()
            self.state = 141
            self.match(fourierParser.T__2)
            self.state = 142
            self.match(fourierParser.T__19)
            self.state = 143
            self.match(fourierParser.T__18)
            self.state = 144
            self.expr()
            self.state = 145
            self.match(fourierParser.T__2)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def value(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(fourierParser.ValueContext)
            else:
                return self.getTypedRuleContext(fourierParser.ValueContext,i)


        def VAR(self):
            return self.getToken(fourierParser.VAR, 0)

        def comp_operator(self):
            return self.getTypedRuleContext(fourierParser.Comp_operatorContext,0)


        def getRuleIndex(self):
            return fourierParser.RULE_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr" ):
                listener.enterExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr" ):
                listener.exitExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpr" ):
                return visitor.visitExpr(self)
            else:
                return visitor.visitChildren(self)




    def expr(self):

        localctx = fourierParser.ExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_expr)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 147
            self.value()
            self.state = 148
            self.match(fourierParser.T__19)
            self.state = 149
            self.match(fourierParser.VAR)
            self.state = 150
            self.comp_operator()
            self.state = 151
            self.value()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ValueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NUMBER(self):
            return self.getToken(fourierParser.NUMBER, 0)

        def VAR(self):
            return self.getToken(fourierParser.VAR, 0)

        def getRuleIndex(self):
            return fourierParser.RULE_value

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterValue" ):
                listener.enterValue(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitValue" ):
                listener.exitValue(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitValue" ):
                return visitor.visitValue(self)
            else:
                return visitor.visitChildren(self)




    def value(self):

        localctx = fourierParser.ValueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_value)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 153
            _la = self._input.LA(1)
            if not(_la==25 or _la==28):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Comp_operatorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return fourierParser.RULE_comp_operator

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterComp_operator" ):
                listener.enterComp_operator(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitComp_operator" ):
                listener.exitComp_operator(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitComp_operator" ):
                return visitor.visitComp_operator(self)
            else:
                return visitor.visitChildren(self)




    def comp_operator(self):

        localctx = fourierParser.Comp_operatorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_comp_operator)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 155
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 31457280) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





