# Generated from Iterable.g4 by ANTLR 4.13.0
from antlr4 import *
if "." in __name__:
    from .IterableParser import IterableParser
else:
    from IterableParser import IterableParser

# This class defines a complete generic visitor for a parse tree produced by IterableParser.

class IterableVisitor(ParseTreeVisitor):

    # Visit a parse tree produced by IterableParser#start.
    def visitStart(self, ctx:IterableParser.StartContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by IterableParser#mapExpr.
    def visitMapExpr(self, ctx:IterableParser.MapExprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by IterableParser#filterExpr.
    def visitFilterExpr(self, ctx:IterableParser.FilterExprContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by IterableParser#iterable.
    def visitIterable(self, ctx:IterableParser.IterableContext):
        return self.visitChildren(ctx)



del IterableParser