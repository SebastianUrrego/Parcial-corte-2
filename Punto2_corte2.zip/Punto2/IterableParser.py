# Generated from Iterable.g4 by ANTLR 4.13.0
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,10,40,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,1,0,1,0,3,0,11,8,0,1,1,
        1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,3,1,3,1,3,
        1,3,5,3,31,8,3,10,3,12,3,34,9,3,3,3,36,8,3,1,3,1,3,1,3,0,0,4,0,2,
        4,6,0,0,38,0,10,1,0,0,0,2,12,1,0,0,0,4,19,1,0,0,0,6,26,1,0,0,0,8,
        11,3,2,1,0,9,11,3,4,2,0,10,8,1,0,0,0,10,9,1,0,0,0,11,1,1,0,0,0,12,
        13,5,1,0,0,13,14,5,2,0,0,14,15,5,8,0,0,15,16,5,3,0,0,16,17,3,6,3,
        0,17,18,5,4,0,0,18,3,1,0,0,0,19,20,5,5,0,0,20,21,5,2,0,0,21,22,5,
        8,0,0,22,23,5,3,0,0,23,24,3,6,3,0,24,25,5,4,0,0,25,5,1,0,0,0,26,
        35,5,6,0,0,27,32,5,9,0,0,28,29,5,3,0,0,29,31,5,9,0,0,30,28,1,0,0,
        0,31,34,1,0,0,0,32,30,1,0,0,0,32,33,1,0,0,0,33,36,1,0,0,0,34,32,
        1,0,0,0,35,27,1,0,0,0,35,36,1,0,0,0,36,37,1,0,0,0,37,38,5,7,0,0,
        38,7,1,0,0,0,3,10,32,35
    ]

class IterableParser ( Parser ):

    grammarFileName = "Iterable.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'MAP'", "'('", "','", "')'", "'FILTER'", 
                     "'['", "']'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "ID", "NUMBER", "WS" ]

    RULE_start = 0
    RULE_mapExpr = 1
    RULE_filterExpr = 2
    RULE_iterable = 3

    ruleNames =  [ "start", "mapExpr", "filterExpr", "iterable" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    ID=8
    NUMBER=9
    WS=10

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.0")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class StartContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def mapExpr(self):
            return self.getTypedRuleContext(IterableParser.MapExprContext,0)


        def filterExpr(self):
            return self.getTypedRuleContext(IterableParser.FilterExprContext,0)


        def getRuleIndex(self):
            return IterableParser.RULE_start

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStart" ):
                listener.enterStart(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStart" ):
                listener.exitStart(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStart" ):
                return visitor.visitStart(self)
            else:
                return visitor.visitChildren(self)




    def start(self):

        localctx = IterableParser.StartContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_start)
        try:
            self.state = 10
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [1]:
                self.enterOuterAlt(localctx, 1)
                self.state = 8
                self.mapExpr()
                pass
            elif token in [5]:
                self.enterOuterAlt(localctx, 2)
                self.state = 9
                self.filterExpr()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MapExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(IterableParser.ID, 0)

        def iterable(self):
            return self.getTypedRuleContext(IterableParser.IterableContext,0)


        def getRuleIndex(self):
            return IterableParser.RULE_mapExpr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMapExpr" ):
                listener.enterMapExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMapExpr" ):
                listener.exitMapExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMapExpr" ):
                return visitor.visitMapExpr(self)
            else:
                return visitor.visitChildren(self)




    def mapExpr(self):

        localctx = IterableParser.MapExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_mapExpr)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 12
            self.match(IterableParser.T__0)
            self.state = 13
            self.match(IterableParser.T__1)
            self.state = 14
            self.match(IterableParser.ID)
            self.state = 15
            self.match(IterableParser.T__2)
            self.state = 16
            self.iterable()
            self.state = 17
            self.match(IterableParser.T__3)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FilterExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(IterableParser.ID, 0)

        def iterable(self):
            return self.getTypedRuleContext(IterableParser.IterableContext,0)


        def getRuleIndex(self):
            return IterableParser.RULE_filterExpr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFilterExpr" ):
                listener.enterFilterExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFilterExpr" ):
                listener.exitFilterExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFilterExpr" ):
                return visitor.visitFilterExpr(self)
            else:
                return visitor.visitChildren(self)




    def filterExpr(self):

        localctx = IterableParser.FilterExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_filterExpr)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 19
            self.match(IterableParser.T__4)
            self.state = 20
            self.match(IterableParser.T__1)
            self.state = 21
            self.match(IterableParser.ID)
            self.state = 22
            self.match(IterableParser.T__2)
            self.state = 23
            self.iterable()
            self.state = 24
            self.match(IterableParser.T__3)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IterableContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NUMBER(self, i:int=None):
            if i is None:
                return self.getTokens(IterableParser.NUMBER)
            else:
                return self.getToken(IterableParser.NUMBER, i)

        def getRuleIndex(self):
            return IterableParser.RULE_iterable

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIterable" ):
                listener.enterIterable(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIterable" ):
                listener.exitIterable(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIterable" ):
                return visitor.visitIterable(self)
            else:
                return visitor.visitChildren(self)




    def iterable(self):

        localctx = IterableParser.IterableContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_iterable)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 26
            self.match(IterableParser.T__5)
            self.state = 35
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==9:
                self.state = 27
                self.match(IterableParser.NUMBER)
                self.state = 32
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==3:
                    self.state = 28
                    self.match(IterableParser.T__2)
                    self.state = 29
                    self.match(IterableParser.NUMBER)
                    self.state = 34
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)



            self.state = 37
            self.match(IterableParser.T__6)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





