# Generated from Iterable.g4 by ANTLR 4.13.0
from antlr4 import *
if "." in __name__:
    from .IterableParser import IterableParser
else:
    from IterableParser import IterableParser

# This class defines a complete listener for a parse tree produced by IterableParser.
class IterableListener(ParseTreeListener):

    # Enter a parse tree produced by IterableParser#start.
    def enterStart(self, ctx:IterableParser.StartContext):
        pass

    # Exit a parse tree produced by IterableParser#start.
    def exitStart(self, ctx:IterableParser.StartContext):
        pass


    # Enter a parse tree produced by IterableParser#mapExpr.
    def enterMapExpr(self, ctx:IterableParser.MapExprContext):
        pass

    # Exit a parse tree produced by IterableParser#mapExpr.
    def exitMapExpr(self, ctx:IterableParser.MapExprContext):
        pass


    # Enter a parse tree produced by IterableParser#filterExpr.
    def enterFilterExpr(self, ctx:IterableParser.FilterExprContext):
        pass

    # Exit a parse tree produced by IterableParser#filterExpr.
    def exitFilterExpr(self, ctx:IterableParser.FilterExprContext):
        pass


    # Enter a parse tree produced by IterableParser#iterable.
    def enterIterable(self, ctx:IterableParser.IterableContext):
        pass

    # Exit a parse tree produced by IterableParser#iterable.
    def exitIterable(self, ctx:IterableParser.IterableContext):
        pass



del IterableParser